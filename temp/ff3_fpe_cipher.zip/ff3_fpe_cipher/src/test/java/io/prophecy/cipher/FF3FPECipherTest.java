package io.prophecy.cipher;

import org.junit.Test;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;

public class FF3FPECipherTest {
    @Test
    public void ff3Encryption() {

        Map<String, String> expectedOutputs = new HashMap<String, String>() {{
            put("JO", "JM");
            put("SH", "IQ");
            put("96", "29");
            put("MAM", "MHF");
            put("MMT", "JTZ");
            put("120", "520");
            put("JO1", "DN1");
            put("TBD4", "FCS8");
            put("8888", "2271");
            put("MBP01", "UMY67");
            put("PA165", "LP093");
            put("X-31", "W-57");
            put("CC-79", "LS-59");
            put("T-584", "S-354");
            put("AMC-52", "HPQ-09");
            put("AMC-78", "LZJ-50");
            put("GRGLP-57", "NDKKY-97");
            put("278083-1", "492928-3");
            put("PDGLP1-1", "QJWVY3-6");
            put("PA14976-4", "LM03239-0");
            put("PA14976-7", "NG76607-4");
            put("cs", "xg");
            put("CS", "UL");
            put("pas", "ciw");
            put("Pas", "Jkm");
            put("PAS", "PVZ");
            put("ASAC-4455", "AFXC-2357");
            put("ASACHIN-22334455", "SSYCRKS-39210759");
            put("HZFN392817G", "LNVE066115H");
            put("0", "4");
            put("A0801051441", "Z3828920127");
            put("D", "G");
            put("PA-B9958142", "KA-V1772461");
            put("R", "A");
        }};

        String key = "6F6826F7F791E1A8EE7E1BD7717D3EDD";
        String tweak = "CBD09280979564";
        FF3FPECipher ff3FPECipher = new FF3FPECipher(key, tweak);
        for (String s : expectedOutputs.keySet()) {
            try {
                assertEquals(ff3FPECipher.encryptPreservingFormat(s), expectedOutputs.get(s));
            } catch (Exception e) {
                throw new RuntimeException(s + " : " + e.getMessage(), e);
            }
        }
    }

    @Test
    public void ff3Decryption() throws IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException {

        String key = "6F6826F7F791E1A8EE7E1BD7717D3EDD";
        String tweak = "CBD09280979564";
        FF3FPECipher ff3FPECipher = new FF3FPECipher(key, tweak);
        assertEquals("ASACHIN-22334455", ff3FPECipher.decryptPreservingFormat("SSYCRKS-39210759"));
        assertEquals("HZFN392817G", ff3FPECipher.decryptPreservingFormat("LNVE066115H"));
    }
}

package io.prophecy.cipher;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.xml.bind.DatatypeConverter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

public class FF3FPECipher {

    private String key;
    private String tweak;

    public FF3FPECipher(String key, String tweak) {
        this.key = key;
        this.tweak = tweak;
    }

    private static String hashSHA256AsStr(String input, int size) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hashBytes = digest.digest(DatatypeConverter.parseHexBinary(input));
        return DatatypeConverter.printHexBinary(Arrays.copyOf(hashBytes, size));
    }

    private static String reconstituteParts(String format, String chars, String digits) {
        char[] formatChars = format.toCharArray();
        int charsIndex = 0;
        int digitsIndex = 0;
        char[] digitsVec = digits.toCharArray();
        char[] charsVec = chars.toCharArray();
        StringBuilder result = new StringBuilder();

        for (char c : formatChars) {
            if (c == '0') {
                result.append(digitsVec[digitsIndex]);
                digitsIndex++;
            } else if (c == 'a') {
                result.append(charsVec[charsIndex]);
                charsIndex++;
            } else if (c == 'A') {
                result.append(Character.toUpperCase(charsVec[charsIndex]));
                charsIndex++;
            } else {
                result.append(c);
            }
        }

        return result.toString();
    }

    private String padString(String input, int length) {

        if (input.length() > 8) return input;

        StringBuilder result = new StringBuilder(input);
        while (result.length() < length) {
            result.append(0x00);
        }
        return result.toString();
    }

    public String encryptPreservingFormat(String inputStr) throws IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException {
        String chars = inputStr.replaceAll("[^a-zA-Z]", "").toLowerCase();
        String digits = inputStr.replaceAll("[^0-9]", "");
        FPEFormat formatInfo = FPEUtil.getFormatAndTweaks(inputStr);
        if (!"a".equals(String.valueOf((char) 97))) {
            throw new RuntimeException("FF3.encryptPreservingFormat() is supported only when the native character set is iso-8859-1.");
        }
        if (chars.length() > 255 || digits.length() > 255) {
            throw new RuntimeException("EncryptPreservingFormat will be only supported for strings with 255 or fewer alphabetic characters and 255 or fewer numeric characters.");
        }

        if (chars.length() > 0) {
            String localTweak = (formatInfo.skipLowercaseTweak) ? tweak :
                    hashSHA256AsStr(FPEUtil.getFPETweakHash("00", tweak, formatInfo.format, digits), 8);
            chars = new FF3Cipher(this.key, localTweak, FF3Cipher.ASCII_LOWERCASE).encrypt(chars);
        }

        if (digits.length() > 0) {
            String localTweak = formatInfo.skipDigitTweak ? tweak :
                    hashSHA256AsStr(FPEUtil.getFPETweakHash("01", tweak, formatInfo.format, chars), 8);
            digits = new FF3Cipher(this.key, localTweak).encrypt(digits);
        }

        return reconstituteParts(formatInfo.format, chars, digits);
    }


    public String decryptPreservingFormat(String inputStr) throws IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException {
        // Separate out the alphabetic chars and make all letters lowercase.
        String chars = inputStr.replaceAll("[^a-zA-Z]", "").toLowerCase();
        // Separate out the numeric characters
        String digits = inputStr.replaceAll("[^0-9]", "");
        // Get format information
        FPEFormat formatInfo = FPEUtil.getFormatAndTweaks(inputStr);
        if (!"a".equals(String.valueOf((char) 97))) {
            throw new RuntimeException("FF3.decryptPreservingFormat() is supported only when the native character set is iso-8859-1.");
        }

        if (digits.length() > 0) {
            String localTweak = (formatInfo.skipDigitTweak) ? this.tweak :
                    hashSHA256AsStr(FPEUtil.getFPETweakHash("01", this.tweak, formatInfo.format, chars), 8);
            digits = new FF3Cipher(this.key, localTweak).decrypt(digits);
        }

        if (chars.length() > 0) {
            String localTweak = (formatInfo.skipLowercaseTweak) ? this.tweak :
                    hashSHA256AsStr(FPEUtil.getFPETweakHash("00", this.tweak, formatInfo.format, digits), 8);
            chars = new FF3Cipher(this.key, localTweak, FF3Cipher.ASCII_LOWERCASE).decrypt(chars);
        }
        return reconstituteParts(formatInfo.format, chars, digits);
    }

}

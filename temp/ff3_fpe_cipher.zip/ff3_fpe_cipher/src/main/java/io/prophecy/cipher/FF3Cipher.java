package io.prophecy.cipher;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

public class FF3Cipher {
    private static final int NUM_ROUNDS = 8;
    private static final int BLOCK_SIZE = 16;
    private static final int TWEAK_LEN = 8;
    private static final int TWEAK_LEN_NEW = 7;
    private static final int HALF_TWEAK_LEN = 4;
    private static int MAX_RADIX = 256;
    private static final Logger logger = LogManager.getLogger(FF3Cipher.class.getName());
    public static int DOMAIN_MIN = 1000000;
    public static final String DIGITS = "0123456789";
    public static final String ASCII_LOWERCASE = "abcdefghijklmnopqrstuvwxyz";
    public static final String ASCII_UPPERCASE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private final int radix;
    private final String alphabet;
    private byte[] tweakBytes;
    private final int minLen;
    private final int maxLen;
    private final Cipher aesCipher;
    private final Cipher aesCipher1;

    public FF3Cipher(String key, String tweak) {
        this(key, tweak, 10);
    }

    public FF3Cipher(String key, byte[] tweakBytes, String alphabet) {
        this.alphabet = alphabet;
        this.radix = alphabet.length();
        byte[] keyBytes = hexStringToByteArray(key);
        this.minLen = 2;
//        this.minLen = (int)Math.floor(Math.log((double)this.radix));
        this.maxLen = (int) (2.0 * Math.floor(Math.log(Math.pow(2.0, 96.0)) / Math.log((double) this.radix)));
        int keyLen = keyBytes.length;
        if (keyLen != 16 && keyLen != 24 && keyLen != 32) {
            throw new IllegalArgumentException("key length " + keyLen + " but must be 128, 192, or 256 bits");
        } else if (this.radix >= 2 && this.radix <= MAX_RADIX) {
            if (this.minLen >= 2 && this.maxLen >= this.minLen) {
                this.tweakBytes = tweakBytes;

                try {
                    SecretKeySpec keySpec1 = new SecretKeySpec(keyBytes, "AES");
                    this.aesCipher1 = Cipher.getInstance("AES/ECB/NoPadding");
                    this.aesCipher1.init(1, keySpec1);

                    this.reverseBytes(keyBytes);
                    SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");
                    this.aesCipher = Cipher.getInstance("AES/ECB/NoPadding");
                    this.aesCipher.init(1, keySpec);

                } catch (NoSuchPaddingException | InvalidKeyException | NoSuchAlgorithmException var7) {
                    throw new RuntimeException(var7);
                }
            } else {
                throw new IllegalArgumentException("minLen or maxLen invalid, adjust your radix");
            }
        } else {
            throw new IllegalArgumentException("radix must be between 2 and 256, inclusive");
        }
    }

    public FF3Cipher(String key, String tweak, String alphabet) {
        this(key, hexStringToByteArray(tweak), alphabet);
    }

    public FF3Cipher(String key, String tweak, int radix) {
        this(key, hexStringToByteArray(tweak), alphabetForBase(radix));
    }

    public String encrypt(String plaintext, String tweak) throws BadPaddingException, IllegalBlockSizeException {
        this.tweakBytes = hexStringToByteArray(tweak);
        return this.encrypt(plaintext);
    }

    int little2big(int i) {
        return (i & 0xff) << 24 | (i & 0xff00) << 8 | (i & 0xff0000) >> 8 | (i >> 24) & 0xff;
    }

    public int genMask1(int x, int radix, byte[] tweak, int i) throws IllegalBlockSizeException, BadPaddingException {
        byte[] plaintext = new byte[]{(byte) x, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, (byte) (tweak[3] ^ (8 + i))};
        byte[] ciphertext = this.aesCipher1.doFinal(plaintext);
        int littleEndianText = ciphertext[0] & 255 | (ciphertext[1] & 255) << 8 | (ciphertext[2] & 255) << 16 | (ciphertext[3] & 255) << 24;
        Long rnd = Integer.toUnsignedLong(littleEndianText);
        return (int) (rnd % radix);
    }

    public String encrypt1(String plaintext) throws BadPaddingException, IllegalBlockSizeException {
        int x = decode_int(plaintext, this.alphabet).intValue();
        int d = this.radix / 2;
        byte[] tweak64 = this.tweakBytes.length == 7 ? calculateTweak64_FF3_1(this.tweakBytes) : this.tweakBytes;
        int left = x % 2;
        int right = x % d;
        byte[] tweakLeft4 = Arrays.copyOf(tweak64, 4), tweakRight4 = Arrays.copyOfRange(tweak64, 4, 8);

        for (byte i = 0; i < 4; ++i) {
            int m1 = genMask1(right, 2, tweakRight4, 2 * i);
            left = (left + m1) % 2;
            int m2 = genMask1(left, d, tweakLeft4, 2 * i + 1);
            right = (right + m2) % d;
        }
        int c = (left % 2 == right % 2) ? right : d + right;
        return encode_int_r(BigInteger.valueOf(c), this.alphabet, 1);
    }

    public String encrypt(String plaintext) throws BadPaddingException, IllegalBlockSizeException {
        int n = plaintext.length();
        if (n == 1) {
            if (this.tweakBytes.length != 8 && this.tweakBytes.length != 7) {
                throw new IllegalArgumentException(String.format("tweak length %d is invalid: tweak must be 56 or 64 bits", this.tweakBytes.length));
            }
            return this.encrypt1(plaintext);
        } else if (n >= this.minLen && n <= this.maxLen) {
            int u = (int) Math.ceil((double) n / 2.0);
            int v = n - u;
            String A = plaintext.substring(0, u);
            String B = plaintext.substring(u);
            logger.trace("r {} A {} B {}", this.radix, A, B);
            if (this.tweakBytes.length != 8 && this.tweakBytes.length != 7) {
                throw new IllegalArgumentException(String.format("tweak length %d is invalid: tweak must be 56 or 64 bits", this.tweakBytes.length));
            } else {
                logger.trace("tweak: {}", byteArrayToHexString(this.tweakBytes));
                byte[] tweak64 = this.tweakBytes.length == 7 ? calculateTweak64_FF3_1(this.tweakBytes) : this.tweakBytes;
                byte[] Tl = Arrays.copyOf(tweak64, 4);
                byte[] Tr = Arrays.copyOfRange(tweak64, 4, 8);
                BigInteger modU = BigInteger.valueOf((long) this.radix).pow(u);
                BigInteger modV = BigInteger.valueOf((long) this.radix).pow(v);
                logger.trace("u {} v {} modU: {} modV: {}", u, v, modU, modV);
                logger.trace("tL: {} tR: {}", byteArrayToHexString(Tl), byteArrayToHexString(Tr));

                for (byte i = 0; i < 8; ++i) {
                    int m;
                    byte[] W;
                    if (i % 2 == 0) {
                        m = u;
                        W = Tr;
                    } else {
                        m = v;
                        W = Tl;
                    }

                    byte[] P = calculateP(i, this.alphabet, W, B);
                    this.reverseBytes(P);
                    byte[] S = this.aesCipher.doFinal(P);
                    this.reverseBytes(S);
                    logger.trace("\tS: {}", byteArrayToHexString(S));
                    BigInteger y = new BigInteger(byteArrayToHexString(S), 16);
                    BigInteger c = decode_int(reverseString(A), this.alphabet);
                    c = c.add(y);
                    if (i % 2 == 0) {
                        c = c.mod(modU);
                    } else {
                        c = c.mod(modV);
                    }

                    logger.trace("\tm: {} A: {} c: {} y: {}", m, A, c, y);
                    String C = encode_int_r(c, this.alphabet, m);
                    A = B;
                    B = C;
                    logger.trace("A: {} B: {}", A, C);
                }

                return A + B;
            }
        } else {
            throw new IllegalArgumentException(String.format("message length %d is not within min %d and max %d bounds", n, this.minLen, this.maxLen));
        }
    }

    public String decrypt(String ciphertext, String tweak) throws BadPaddingException, IllegalBlockSizeException {
        this.tweakBytes = hexStringToByteArray(tweak);
        return this.decrypt(ciphertext);
    }

    public String decrypt(String ciphertext) throws BadPaddingException, IllegalBlockSizeException {
        int n = ciphertext.length();
        if (n >= this.minLen && n <= this.maxLen) {
            int u = (int) Math.ceil((double) n / 2.0);
            int v = n - u;
            String A = ciphertext.substring(0, u);
            String B = ciphertext.substring(u);
            if (this.tweakBytes.length != 8 && this.tweakBytes.length != 7) {
                throw new IllegalArgumentException(String.format("tweak length %d is invalid: tweak must be 56 or 64 bits", this.tweakBytes.length));
            } else {
                logger.trace("tweak: {}", byteArrayToHexString(this.tweakBytes));
                byte[] tweak64 = this.tweakBytes.length == 7 ? calculateTweak64_FF3_1(this.tweakBytes) : this.tweakBytes;
                byte[] Tl = Arrays.copyOf(tweak64, 4);
                byte[] Tr = Arrays.copyOfRange(tweak64, 4, 8);
                BigInteger modU = BigInteger.valueOf((long) this.radix).pow(u);
                BigInteger modV = BigInteger.valueOf((long) this.radix).pow(v);
                logger.trace("modU: {} modV: {}", modU, modV);
                logger.trace("tL: {} tR: {}", byteArrayToHexString(Tl), byteArrayToHexString(Tr));

                for (byte i = 7; i >= 0; --i) {
                    int m;
                    byte[] W;
                    if (i % 2 == 0) {
                        m = u;
                        W = Tr;
                    } else {
                        m = v;
                        W = Tl;
                    }

                    byte[] P = calculateP(i, this.alphabet, W, A);
                    this.reverseBytes(P);
                    byte[] S = this.aesCipher.doFinal(P);
                    this.reverseBytes(S);
                    logger.trace("\tS: {}", byteArrayToHexString(S));
                    BigInteger y = new BigInteger(byteArrayToHexString(S), 16);
                    BigInteger c = decode_int(reverseString(B), this.alphabet);
                    c = c.subtract(y);
                    if (i % 2 == 0) {
                        c = c.mod(modU);
                    } else {
                        c = c.mod(modV);
                    }

                    logger.trace("\tm: {} B: {} c: {} y: {}", m, B, c, y);
                    String C = encode_int_r(c, this.alphabet, m);
                    B = A;
                    A = C;
                    logger.trace("A: {} B: {}", C, B);
                }

                return A + B;
            }
        } else {
            throw new IllegalArgumentException(String.format("message length %d is not within min %d and max %d bounds", n, this.minLen, this.maxLen));
        }
    }

    protected static byte[] calculateTweak64_FF3_1(byte[] tweak56) {
        byte[] tweak64 = new byte[]{tweak56[0], tweak56[1], tweak56[2], (byte) (tweak56[3] & 240), tweak56[4], tweak56[5], tweak56[6], (byte) ((tweak56[3] & 15) << 4)};
        return tweak64;
    }

    protected static byte[] calculateP(int i, String alphabet, byte[] W, String B) {
        byte[] P = new byte[16];
        P[0] = W[0];
        P[1] = W[1];
        P[2] = W[2];
        P[3] = (byte) (W[3] ^ i);
        B = reverseString(B);
        byte[] bBytes = decode_int(B, alphabet).toByteArray();
        System.arraycopy(bBytes, 0, P, 16 - bBytes.length, bBytes.length);
        logger.trace("round: {} W: {} P: {}", i, byteArrayToHexString(W), byteArrayToIntString(P));
        return P;
    }

    protected static String reverseString(String s) {
        return (new StringBuilder(s)).reverse().toString();
    }

    protected void reverseBytes(byte[] b) {
        for (int i = 0; i < b.length / 2; ++i) {
            byte temp = b[i];
            b[i] = b[b.length - i - 1];
            b[b.length - i - 1] = temp;
        }

    }

    protected static byte[] hexStringToByteArray(String s) {
        byte[] data = new byte[s.length() / 2];

        for (int i = 0; i < s.length(); i += 2) {
            data[i / 2] = Integer.decode("0x" + s.charAt(i) + s.charAt(i + 1)).byteValue();
        }

        return data;
    }

    protected static String byteArrayToHexString(byte[] byteArray) {
        StringBuilder sb = new StringBuilder();
        byte[] var2 = byteArray;
        int var3 = byteArray.length;

        for (int var4 = 0; var4 < var3; ++var4) {
            byte b = var2[var4];
            String aByte = String.format("%02X", b);
            sb.append(aByte);
        }

        return sb.toString();
    }

    protected static String byteArrayToIntString(byte[] byteArray) {
        StringBuilder sb = new StringBuilder();
        sb.append('[');
        byte[] var2 = byteArray;
        int var3 = byteArray.length;

        for (int var4 = 0; var4 < var3; ++var4) {
            byte b = var2[var4];
            String aByte = String.format("%d ", b & 255);
            sb.append(aByte);
        }

        sb.append(']');
        return sb.toString();
    }

    protected static String encode_int_r(BigInteger n, String alphabet, int length) {
        char[] x = new char[length];
        int i = 0;

        BigInteger b;
        for (BigInteger bbase = BigInteger.valueOf((long) alphabet.length()); n.compareTo(bbase) >= 0; x[i++] = alphabet.charAt(b.intValue())) {
            b = n.mod(bbase);
            n = n.divide(bbase);
        }

        for (x[i++] = alphabet.charAt(n.intValue()); i < length; x[i++] = alphabet.charAt(0)) {
        }

        return new String(x);
    }

    protected static BigInteger decode_int(String str, String alphabet) {
        int strlen = str.length();
        BigInteger base = BigInteger.valueOf((long) alphabet.length());
        BigInteger num = BigInteger.ZERO;
        int idx = 0;
        char[] var6 = str.toCharArray();
        int var7 = var6.length;

        for (int var8 = 0; var8 < var7; ++var8) {
            char each = var6[var8];
            int exponent = strlen - (idx + 1);
            num = num.add(base.pow(exponent).multiply(BigInteger.valueOf((long) alphabet.indexOf(each))));
            ++idx;
        }

        return num;
    }

    protected static String alphabetForBase(int base) {
        switch (base) {
            case 10:
                return "0123456789";
            case 26:
                return "0123456789abcdefghijklmnop";
            case 36:
                return "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            case 64:
                return "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
            default:
                throw new RuntimeException("Unsupported radix");
        }
    }
}

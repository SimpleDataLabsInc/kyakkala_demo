package io.prophecy.cipher;

import org.apache.commons.lang3.StringUtils;

import javax.xml.bind.DatatypeConverter;

class FPEFormat {

    String format;
    Boolean skipDigitTweak;
    Boolean skipLowercaseTweak;

    public FPEFormat(String format, Boolean skipDigitTweak, Boolean skipLowercaseTweak) {
        this.format = format;
        this.skipDigitTweak = skipDigitTweak;
        this.skipLowercaseTweak = skipLowercaseTweak;
    }


}

public class FPEUtil {

    public static FPEFormat getFormatAndTweaks(String input) {
        char[] inputChars = input.toCharArray();
        int hasDigits = 0;
        int hasLowercase = 0;
        int hasUppercase = 0;
        int hasOther = 0;

        StringBuilder format = new StringBuilder();

        for (char c : inputChars) {
            if (c >= '0' && c <= '9') {
                format.append('0');
                hasDigits = 1;
            } else if (c >= 'a' && c <= 'z') {
                format.append('a');
                hasLowercase = 1;
            } else if (c >= 'A' && c <= 'Z') {
                format.append('A');
                hasUppercase = 1;
            } else {
                hasOther = 1;
                format.append(c);
            }
        }
        boolean skipDigitTweak = (hasDigits == 1 && hasLowercase == 0 && hasUppercase == 0 && hasOther == 0);
        boolean skipLowercaseTweak = (hasDigits == 0 && hasLowercase == 1 && hasUppercase == 0 && hasOther == 0);

        return new FPEFormat(format.toString(), skipDigitTweak, skipLowercaseTweak);
    }

    public static String getFPETweakHash(String i, String tweak, String format, String payload) {

        StringBuilder result = new StringBuilder();

        result.append(i);
        result.append("000000");
        result.append(StringUtils.rightPad(tweak, 16, '0'));
        result.append(StringUtils.leftPad(Integer.toHexString(format.length()), 2, '0'));
        result.append("000000");
        result.append(DatatypeConverter.printHexBinary(format.getBytes()));
        result.append(StringUtils.leftPad(Integer.toHexString(payload.length()), 2, '0'));
        result.append("000000");
        result.append(DatatypeConverter.printHexBinary(payload.getBytes()));

        return result.toString();
    }
}

